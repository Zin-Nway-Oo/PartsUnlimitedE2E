﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace furnitureProject
{
    public partial class login : Form
    {
        DataSet1TableAdapters.userTableAdapter u = new DataSet1TableAdapters.userTableAdapter();
        DataTable dt = new DataTable();
        string username = "";
        string password = "";
        
        public login()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            dt = u.GetData();
            username = txtusername.Text;
            password = txtpassword.Text;
            int row = dt.Rows.Count;
            for(int i=0;i<row;i++)
            {
                if(username==dt.Rows[i][1].ToString() && password == dt.Rows[i][2].ToString())
                {
                    this.Hide();
                    main m = new main();
                    m.showid(dt.Rows[i][0].ToString(), username); 
                    m.ShowDialog();
                }
                else
                {
                    MessageBox.Show("invalid username and password");
                    txtusername.Text = "";
                    txtpassword.Text = "";
                }
            }
        }

        private void login_Load(object sender, EventArgs e)
        {
            
        }
    }
}
