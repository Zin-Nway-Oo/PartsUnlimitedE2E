﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace furnitureProject
{
    public partial class main : Form
    {
        public void showid(string id, string name)
        {
            label1.Text = id;
            label2.Text = name;
        }
        public main()
        {
            InitializeComponent();
        }

        private void main_Load(object sender, EventArgs e)
        {

        }
    }
}
